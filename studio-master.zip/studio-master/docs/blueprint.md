# **App Name**: Detecció Digital

## Core Features:

- Real-time Analysis Dashboard: Display a dashboard with real-time analysis of hate speech and digital violence metrics.
- Sentiment Analysis: Analyze sentiment and emotions in text using the OpenAI API.
- Data Filtering: Filter data by channel, source, emotion, country, language, or keywords.
- Content Summarization and Classification: Use the OpenAI API as a tool to generate summaries of discussions or classify content based on predefined categories.
- Customizable Reports: Display customizable graphs and reports.

## Style Guidelines:

- Primary color: White (#FFFFFF) for a clean and modern look.
- Secondary color: Light gray (#F0F0F0) for backgrounds and subtle accents.
- Accent color: Purple (#800080) to symbolize overcoming gender based violence.
- Clear and accessible typography with good contrast.
- Use meaningful and accessible icons to represent different data categories and actions.
- A clean and structured layout to present complex data in an understandable way.

## Original User Request:
1. Presentació del projecte
Estem desenvolupant una plataforma digital per a la detecció, prevenció i reparació de la violència masclista en l’àmbit digital. L'objectiu és crear una eina tecnològica innovadora que permeti identificar i combatre discursos discriminatoris a través de la monitorització automatitzada de múltiples canals digitals i xarxes socials.

Aquest projecte compta amb una visió interseccional i feminista, posant el focus en garantir la seguretat digital de les dones, generar dades per a la incidència política i sensibilitzar la societat sobre la violència digital masclista.
2. Enfocament tecnològic
Hem decidit desenvolupar la nostra pròpia plataforma, evitant solucions preconstruïdes com Mention o Brand24, i apostant per la integració directa de les següents API oficials i tecnologies clau:

- X (Twitter) API
- TikTok for Developers API
- Instagram Graph API (Meta)
- Google Analytics API
- Meta Graph API (Facebook i Instagram)
- WhatsApp Business API
- YouTube Data API
- OpenAI API (intel·ligència artificial per anàlisi de continguts i generació de llenguatge)
- Firebase (autenticació, base de dades en temps real, hosting i notificacions)
- Altres fonts públiques de dades (RSS, podcasts, blogs)
3. Stack tecnològic
La plataforma es desenvoluparà amb el framework Flutter (preferiblement FlutterFlow per agilitzar el desenvolupament inicial), utilitzant el llenguatge Dart. Es requereix compatibilitat multiplataforma (web + mòbil) i capacitat d'integració amb APIs REST/GraphQL, així com amb serveis d'IA i bases de dades al núvol.
4. Funcionalitats previstes
L’eina haurà de tenir:
- Dashboard d’anàlisi en temps real dels discursos d’odi i violència digital.
- Anàlisi de sentiment i emocions (potenciat amb OpenAI i IA pròpia).
- Gràfics i informes personalitzats descarregables (PDF/Excel).
- Alertes automàtiques via Slack, correu electrònic o WhatsApp.
- Filtratge per canal, font, emoció, país, idioma o paraules clau.
- Accés restringit per rols (usuàries, tècniques, institucions).
- Compliment RGPD i disseny accessible (WCAG 2.1).
5. Arquitectura esperada
- Backend amb autenticació i gestió de rols (via Firebase Auth).
- Mòdul de connexió i ingesta de dades via múltiples API.
- Base de dades escalable i segura (via Firebase/Firestore).
- Integració amb OpenAI per a funcionalitats intel·ligents (anàlisi de sentiment, classificació, resums, etc.).
- Interfície UI/UX responsive i clara.
- Notificacions push i alertes configurables.
  