/**
 * Represents a tweet from X.
 */
export interface Tweet {
  /**
   * The unique identifier of the tweet.
   */
  id: string;
  /**
   * The text content of the tweet.
   */
  text: string;
  /**
   * The username of the tweet's author.
   */
  author: string;
  /**
   * The date when the tweet was created.
   */
  createdAt: Date;
}

/**
 * Asynchronously retrieves tweets for a given search term.
 *
 * @param searchTerm The term to search for in tweets.
 * @returns A promise that resolves to a list of Tweet objects.
 */
export async function getTweets(searchTerm: string): Promise<Tweet[]> {
  // TODO: Implement this by calling the X API.

  return [
    {
      id: '12345',
      text: 'This is a sample tweet.',
      author: 'sample_user',
      createdAt: new Date(),
    },
  ];
}
