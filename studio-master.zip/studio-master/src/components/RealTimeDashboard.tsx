

"use client";

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { analyzeSentiment } from '@/ai/flows/analyze-sentiment';
import { classifyContent } from '@/ai/flows/classify-content';
import { summarizeDiscussion } from '@/ai/flows/summarize-discussion';
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { es } from 'date-fns/locale';
import { getTweets } from "@/services/x-api";
import { getFacebookPosts } from "@/services/meta-graph-api";
import { getInstagramPosts } from "@/services/meta-graph-api";
import { getTikTokVideos } from "@/services/tiktok-api";
import { getRssFeedItems } from "@/services/rss-feeds";

const RealTimeDashboard = () => {
  const [inputText, setInputText] = useState('');
  const [sentimentResult, setSentimentResult] = useState<{ sentiment: string; emotion: string; confidence: number; } | null>(null);
  const [classificationResult, setClassificationResult] = useState<{ category: string; confidence: number; } | null>(null);
  const [summaryResult, setSummaryResult] = useState<{ summary: string; } | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [alertName, setAlertName] = useState('');
  const [monitoredCountries, setMonitoredCountries] = useState('');
  const [monitoredLanguages, setMonitoredLanguages] = useState('');

  const handleAnalysis = async () => {
    // Trigger all analysis functions at once
    await handleSentimentAnalysis();
    await handleContentClassification();
    await handleDiscussionSummarization();
  };

  const handleSentimentAnalysis = async () => {
    const result = await analyzeSentiment({ text: inputText });
    setSentimentResult(result);
  };

  const handleContentClassification = async () => {
    const result = await classifyContent({ text: inputText });
    setClassificationResult(result);
  };

  const handleDiscussionSummarization = async () => {
    const result = await summarizeDiscussion({ discussionText: inputText });
    setSummaryResult(result);
  };

  const handleXSearch = async (searchTerm: string) => {
    const results = await getTweets(searchTerm);
    return results.map(tweet => `Tweet from ${tweet.author}: ${tweet.text}`);
  };

  const handleMetaSearch = async (searchTerm: string) => {
    // Facebook
    const facebookResults = await getFacebookPosts(searchTerm);
    const facebookPosts = facebookResults.map(post => `Facebook Post: ${post.message}`);
    // Instagram
    const instagramResults = await getInstagramPosts(searchTerm);
    const instagramPosts = instagramResults.map(post => `Instagram Post: ${post.caption}`);

    return [...facebookPosts, ...instagramPosts];
  };

  const handleTikTokSearch = async (searchTerm: string) => {
    const tiktokResults = await getTikTokVideos(searchTerm);
    return tiktokResults.map(video => `TikTok Video: ${video.description}`);
  };

  const handleRssSearch = async (searchTerm: string) => {
    //For this example I am using a default RSS Feed
    const rssFeedResults = await getRssFeedItems("https://www.example.com/rss");
    return rssFeedResults.map(item => `RSS Feed: ${item.title} - ${item.description}`);
  };


  const handleSearch = async () => {
      let allResults: string[] = [];

      const xResults = await handleXSearch(searchTerm);
      allResults = allResults.concat(xResults);

      const metaResults = await handleMetaSearch(searchTerm);
      allResults = allResults.concat(metaResults);

      const tiktokResults = await handleTikTokSearch(searchTerm);
      allResults = allResults.concat(tiktokResults);

      const rssResults = await handleRssSearch(searchTerm);
      allResults = allResults.concat(rssResults);

      setSearchResults(allResults);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Panel de Análisis en Tiempo Real</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Alert Building Section */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>1. Build your alert</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Label htmlFor="alert-name">Alert name</Label>
            <Input
              id="alert-name"
              placeholder="Enter an alert name here"
              value={alertName}
              onChange={(e) => setAlertName(e.target.value)}
            />

            <Label htmlFor="keyword">Write a keyword</Label>
            <Input
              id="keyword"
              placeholder="Write a keyword"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />

             <Label htmlFor="monitored-sources">Monitored sources</Label>
            <Select>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="x">X (Twitter)</SelectItem>
                <SelectItem value="tiktok">TikTok</SelectItem>
                <SelectItem value="instagram">Instagram</SelectItem>
                <SelectItem value="facebook">Facebook</SelectItem>
                <SelectItem value="youtube">YouTube</SelectItem>
                <SelectItem value="rss">RSS Feeds</SelectItem>
              </SelectContent>
            </Select>

            <Label htmlFor="monitored-countries">Monitored countries</Label>
            <Input
              id="monitored-countries"
              placeholder="Ex: United States, Free"
              value={monitoredCountries}
              onChange={(e) => setMonitoredCountries(e.target.value)}
            />

            <Label htmlFor="monitored-languages">Monitored languages (10 max)</Label>
            <Input
              id="monitored-languages"
              placeholder="Ex: English, French"
              value={monitoredLanguages}
              onChange={(e) => setMonitoredLanguages(e.target.value)}
            />

            <Button onClick={handleSearch} variant="outline">
              Create Alert
            </Button>
          </CardContent>
        </Card>

        {/* Search Results Section */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Resultados de la búsqueda</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] w-full space-y-2">
              {searchResults.length > 0 ? (
                searchResults.map((result, index) => (
                  <div key={index} className="p-2 border rounded-md">
                    {result}
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">
                  No hay resultados para mostrar.
                </p>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RealTimeDashboard;
