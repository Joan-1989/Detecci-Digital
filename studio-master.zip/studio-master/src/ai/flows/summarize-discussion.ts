'use server';
/**
 * @fileOverview A discussion summarization AI agent.
 *
 * - summarizeDiscussion - A function that handles the discussion summarization process.
 * - SummarizeDiscussionInput - The input type for the summarizeDiscussion function.
 * - SummarizeDiscussionOutput - The return type for the summarizeDiscussion function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const SummarizeDiscussionInputSchema = z.object({
  discussionText: z.string().describe('The text of the discussion to summarize.'),
});
export type SummarizeDiscussionInput = z.infer<typeof SummarizeDiscussionInputSchema>;

const SummarizeDiscussionOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the discussion.'),
});
export type SummarizeDiscussionOutput = z.infer<typeof SummarizeDiscussionOutputSchema>;

export async function summarizeDiscussion(input: SummarizeDiscussionInput): Promise<SummarizeDiscussionOutput> {
  return summarizeDiscussionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeDiscussionPrompt',
  input: {
    schema: z.object({
      discussionText: z.string().describe('The text of the discussion to summarize.'),
    }),
  },
  output: {
    schema: z.object({
      summary: z.string().describe('A concise summary of the discussion.'),
    }),
  },
  prompt: `You are an expert summarizer specializing in distilling key topics and arguments from long discussions.

  Please provide a concise summary of the following discussion related to digital violence:

  Discussion Text: {{{discussionText}}}
  `,
});

const summarizeDiscussionFlow = ai.defineFlow<
  typeof SummarizeDiscussionInputSchema,
  typeof SummarizeDiscussionOutputSchema
>({
  name: 'summarizeDiscussionFlow',
  inputSchema: SummarizeDiscussionInputSchema,
  outputSchema: SummarizeDiscussionOutputSchema,
}, async input => {
  const {output} = await prompt(input);
  return output!;
});
