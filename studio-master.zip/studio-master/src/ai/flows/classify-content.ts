'use server';
/**
 * @fileOverview A content classification AI agent.
 *
 * - classifyContent - A function that handles the content classification process.
 * - ClassifyContentInput - The input type for the classifyContent function.
 * - ClassifyContentOutput - The return type for the classifyContent function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const ClassifyContentInputSchema = z.object({
  text: z.string().describe('The text content to classify.'),
});
export type ClassifyContentInput = z.infer<typeof ClassifyContentInputSchema>;

const ClassifyContentOutputSchema = z.object({
  category: z
    .string()
    .describe(
      'The predicted category of the content, chosen from the list of supported categories.'
    ),
  confidence: z
    .number()
    .describe('A confidence score between 0 and 1 representing the certainty of the classification.'),
});
export type ClassifyContentOutput = z.infer<typeof ClassifyContentOutputSchema>;

export async function classifyContent(input: ClassifyContentInput): Promise<ClassifyContentOutput> {
  return classifyContentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'classifyContentPrompt',
  input: {
    schema: z.object({
      text: z.string().describe('The text content to classify.'),
    }),
  },
  output: {
    schema: z.object({
      category: z
        .string()
        .describe(
          'The predicted category of the content, chosen from the list of supported categories: Hate Speech, Digital Violence, Discrimination, or Neutral.'
        ),
      confidence: z
        .number()
        .describe('A confidence score between 0 and 1 representing the certainty of the classification.'),
    }),
  },
  prompt: `You are a content classification expert. Your task is to classify the provided text content into one of the following categories: Hate Speech, Digital Violence, Discrimination, or Neutral. You will also output a confidence score indicating the certainty of your classification.

Text Content: {{{text}}}

Respond in JSON format with the category and confidence score.
`,
});

const classifyContentFlow = ai.defineFlow<
  typeof ClassifyContentInputSchema,
  typeof ClassifyContentOutputSchema
>({
  name: 'classifyContentFlow',
  inputSchema: ClassifyContentInputSchema,
  outputSchema: ClassifyContentOutputSchema,
},
async input => {
  const {output} = await prompt(input);
  return output!;
});
