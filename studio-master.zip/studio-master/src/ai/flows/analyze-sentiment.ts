'use server';
/**
 * @fileOverview A sentiment analysis AI agent.
 *
 * - analyzeSentiment - A function that handles the sentiment analysis process.
 * - AnalyzeSentimentInput - The input type for the analyzeSentiment function.
 * - AnalyzeSentimentOutput - The return type for the analyzeSentiment function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const AnalyzeSentimentInputSchema = z.object({
  text: z.string().describe('The text to analyze for sentiment.'),
});
export type AnalyzeSentimentInput = z.infer<typeof AnalyzeSentimentInputSchema>;

const AnalyzeSentimentOutputSchema = z.object({
  sentiment: z.string().describe('The overall sentiment of the text (e.g., positive, negative, neutral).'),
  emotion: z.string().describe('The primary emotion expressed in the text (e.g., joy, anger, sadness).'),
  confidence: z.number().describe('A confidence score for the sentiment analysis (0-1).'),
});
export type AnalyzeSentimentOutput = z.infer<typeof AnalyzeSentimentOutputSchema>;

export async function analyzeSentiment(input: AnalyzeSentimentInput): Promise<AnalyzeSentimentOutput> {
  return analyzeSentimentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeSentimentPrompt',
  input: {
    schema: z.object({
      text: z.string().describe('The text to analyze for sentiment.'),
    }),
  },
  output: {
    schema: z.object({
      sentiment: z.string().describe('The overall sentiment of the text (e.g., positive, negative, neutral).'),
      emotion: z.string().describe('The primary emotion expressed in the text (e.g., joy, anger, sadness).'),
      confidence: z.number().describe('A confidence score for the sentiment analysis (0-1).'),
    }),
  },
  prompt: `Analyze the sentiment and emotions expressed in the following text related to digital violence:\n\nText: {{{text}}}\n\nProvide the overall sentiment (positive, negative, or neutral), the primary emotion expressed, and a confidence score (0-1) for your analysis.  The sentiment and emotion should be a single word. Do not provide any extra explanation.`, 
});

const analyzeSentimentFlow = ai.defineFlow<
  typeof AnalyzeSentimentInputSchema,
  typeof AnalyzeSentimentOutputSchema
>({
  name: 'analyzeSentimentFlow',
  inputSchema: AnalyzeSentimentInputSchema,
  outputSchema: AnalyzeSentimentOutputSchema,
},
async input => {
  const {output} = await prompt(input);
  return output!;
});

